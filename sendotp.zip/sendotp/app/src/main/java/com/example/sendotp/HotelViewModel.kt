package com.example.sendotp

enum class HotelViewModel
