package com.example.hotel

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.hotel.ui.theme.HotelTheme
data class Hotel(
    val name: String,
    val imageUrl: String,
    val rooms: List<Room>
)

data class Room(
    val roomName: String,
    val price: Int
)


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            HotelTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Greeting(
                        name = "hotel",
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    val priceRange = if (hotel.rooms.isNotEmpty()) {
        val minPrice = hotel.rooms.minOf { it.price }
        val maxPrice = hotel.rooms.maxOf { it.price }
        "$minPrice - $maxPrice"
    } else {
        "Sold Out"
    }
    Card (
        modifier = Modifier
            .padding(8.dp)
            .fillMaxWidth()
            .clickable {
                Toast.makeText(context, "${hotel.name} was selected", Toast.LENGTH_SHORT).show()
            },
        elevation = 4.dp
    ) {


    Column {
        Image(
            painter = remember (hotel.imageUrl),
            contentDescription = "Hotel Image",
            modifier = Modifier.fillMaxWidth().height(200.dp),
            contentScale = ContentScale.Crop
        )
    }
        Text(
            text = "Hello $ hotel!",
            fontSize = 20.sp,
            modifier = modifier
        )
        val priceRange = ""
        val hotel = null
        Text(
            text = if (hotel.rooms.isEmpty()) "Sold Out" else priceRange,
            color = if (hotel.rooms.isEmpty()) Color.Red else Color.Black,
            modifier = modifier
        )
    }
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    HotelTheme {
        Greeting("hotel")
    }
}
